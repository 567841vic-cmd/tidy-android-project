package tw.vic.tidy

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import tw.vic.tidy.core.AppUsage
import tw.vic.tidy.core.BatteryInfo
import tw.vic.tidy.core.JunkCategory
import tw.vic.tidy.core.JunkItem
import tw.vic.tidy.core.JunkScanner
import tw.vic.tidy.core.Perms
import tw.vic.tidy.core.RamInfo
import tw.vic.tidy.core.RecycleBin
import tw.vic.tidy.core.ScanReport
import tw.vic.tidy.core.ShizukuBridge
import tw.vic.tidy.core.StorageInfo
import tw.vic.tidy.core.SystemStats
import tw.vic.tidy.core.UsageRepo
import tw.vic.tidy.core.formatBytes

data class TidyState(
    val storage: StorageInfo = StorageInfo(0L, 0L),
    val ram: RamInfo = RamInfo(0L, 0L),
    val battery: BatteryInfo? = null,
    val hasAllFiles: Boolean = false,
    val hasUsageAccess: Boolean = false,
    val scanning: Boolean = false,
    val scanProgress: Float = 0f,
    val scanLabel: String = "",
    val report: ScanReport? = null,
    val selected: Set<JunkCategory> = emptySet(),
    val cleaning: Boolean = false,
    /** Bytes really released (bin emptied, caches trimmed). */
    val lastFreed: Long = -1L,
    /** Bytes moved into the bin by the last clean. Still on disk. */
    val lastMoved: Long = -1L,
    val trashBytes: Long = 0L,
    val trashCount: Int = 0,
    val usage: List<AppUsage> = emptyList(),
    val shizuku: ShizukuBridge.Status = ShizukuBridge.Status.NOT_INSTALLED,
    val shellBusy: Boolean = false,
    val shellOutput: String = "",
    val notice: String? = null
) {
    val selectedBytes: Long get() = report?.bytesFor(selected) ?: 0L
    val selectedItems: List<JunkItem>
        get() = report?.results.orEmpty()
            .filter { it.category in selected }
            .flatMap { it.items }
}

class TidyViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(TidyState())
    val state: StateFlow<TidyState> = _state.asStateFlow()

    private var scanJob: Job? = null

    @Volatile
    private var scanCancelled = false

    init {
        viewModelScope.launch(Dispatchers.IO) { RecycleBin.purgeExpired(getApplication()) }
        refresh()
    }

    fun refresh() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val storage = withContext(Dispatchers.IO) { SystemStats.storage(ctx) }
            val ram = SystemStats.ram(ctx)
            val battery = SystemStats.battery(ctx)
            val trash = withContext(Dispatchers.IO) { RecycleBin.list(ctx) }
            _state.update {
                it.copy(
                    storage = storage,
                    ram = ram,
                    battery = battery,
                    hasAllFiles = Perms.hasAllFiles(ctx),
                    hasUsageAccess = Perms.hasUsageAccess(ctx),
                    trashBytes = trash.sumOf { e -> e.size },
                    trashCount = trash.size,
                    shizuku = ShizukuBridge.status(ctx)
                )
            }
        }
    }

    fun refreshUsage() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { UsageRepo.topApps(ctx) }
            _state.update { it.copy(usage = list, hasUsageAccess = Perms.hasUsageAccess(ctx)) }
        }
    }

    // ---- Scanning -----------------------------------------------------

    fun startScan() {
        val ctx = getApplication<Application>()
        if (_state.value.scanning) return
        if (!Perms.hasAllFiles(ctx)) {
            _state.update { it.copy(notice = "需要「所有檔案存取權」才能掃描") }
            return
        }
        scanCancelled = false
        _state.update {
            it.copy(
                scanning = true, scanProgress = 0f, scanLabel = "準備掃描",
                report = null, lastFreed = -1L, lastMoved = -1L, selected = emptySet()
            )
        }

        scanJob = viewModelScope.launch(Dispatchers.IO) {
            val bin = RecycleBin.binDir(ctx)
            val report = JunkScanner.scan(
                trashDir = bin,
                onProgress = { scanned, path ->
                    _state.update { s ->
                        s.copy(
                            scanProgress = minOf(0.94f, scanned / 24000f),
                            scanLabel = path
                        )
                    }
                },
                shouldContinue = { !scanCancelled }
            )
            val defaults = report.results
                .map { it.category }
                .filter { it.checkedByDefault }
                .toSet()
            _state.update {
                it.copy(
                    scanning = false,
                    scanProgress = 1f,
                    scanLabel = "",
                    report = report,
                    selected = defaults
                )
            }
            refresh()
        }
    }

    fun cancelScan() {
        scanCancelled = true
        scanJob?.cancel()
        scanJob = null
        _state.update { it.copy(scanning = false, scanLabel = "", scanProgress = 0f) }
    }

    fun toggleCategory(category: JunkCategory) {
        _state.update {
            val next = it.selected.toMutableSet()
            if (!next.remove(category)) next.add(category)
            it.copy(selected = next)
        }
    }

    fun selectDefaults() {
        _state.update { s ->
            s.copy(
                selected = s.report?.results.orEmpty()
                    .map { it.category }.filter { it.checkedByDefault }.toSet()
            )
        }
    }

    fun selectNone() {
        _state.update { it.copy(selected = emptySet()) }
    }

    // ---- Cleaning -----------------------------------------------------

    fun cleanSelected() {
        val ctx = getApplication<Application>()
        val items = _state.value.selectedItems
        if (items.isEmpty() || _state.value.cleaning) return
        _state.update { it.copy(cleaning = true) }

        viewModelScope.launch(Dispatchers.IO) {
            val outcome = RecycleBin.remove(ctx, items)
            val message = buildString {
                append("已移到回收桶 ${outcome.movedCount} 項，清空回收桶後才會釋出空間")
                if (outcome.failedCount > 0) append("；${outcome.failedCount} 項無法移除")
            }
            _state.update {
                it.copy(
                    cleaning = false,
                    lastMoved = outcome.freedBytes,
                    lastFreed = -1L,
                    report = null,
                    selected = emptySet(),
                    notice = message
                )
            }
            refresh()
        }
    }

    fun emptyTrash() {
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val freed = RecycleBin.emptyNow(ctx)
            _state.update {
                it.copy(
                    lastFreed = freed,
                    lastMoved = -1L,
                    notice = "回收桶已清空，釋出 ${formatBytes(freed)}"
                )
            }
            refresh()
        }
    }

    fun restoreTrash() {
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val n = RecycleBin.restoreAll(ctx)
            _state.update { it.copy(notice = "已還原 $n 項") }
            refresh()
        }
    }

    // ---- System cache dialog -----------------------------------------

    private var freeBeforeSystemClear = -1L

    /** Call right before launching the system "clear all caches" dialog. */
    fun beginSystemCacheClear() {
        freeBeforeSystemClear = _state.value.storage.free
    }

    fun onSystemCacheResult(confirmed: Boolean) {
        val ctx = getApplication<Application>()
        val before = freeBeforeSystemClear
        freeBeforeSystemClear = -1L
        if (!confirmed) return
        viewModelScope.launch {
            val after = withContext(Dispatchers.IO) { SystemStats.storage(ctx) }
            val gained = if (before >= 0) after.free - before else 0L
            _state.update {
                it.copy(
                    storage = after,
                    lastFreed = if (gained > 0) gained else it.lastFreed,
                    notice = if (gained > 0) "系統已清除快取，釋出 ${formatBytes(gained)}"
                    else "系統已清除快取"
                )
            }
        }
    }

    // ---- Expert mode --------------------------------------------------

    fun refreshShizuku() {
        val ctx = getApplication<Application>()
        _state.update { it.copy(shizuku = ShizukuBridge.status(ctx)) }
    }

    fun trimAllCaches() {
        val ctx = getApplication<Application>()
        if (_state.value.shellBusy) return
        val label = "清除全機 App 快取"
        _state.update { it.copy(shellBusy = true, shellOutput = "$label…") }
        viewModelScope.launch(Dispatchers.IO) {
            // Measure what matters for a cache trim: disk space, not RAM.
            val before = SystemStats.storage(ctx).free
            val result = ShizukuBridge.trimAllCaches()
            val after = SystemStats.storage(ctx).free
            val gained = after - before
            val text = when {
                result.exitCode != 0 -> "$label 失敗：${result.output}"
                gained > 0 -> "$label 完成，釋出 ${formatBytes(gained)}"
                else -> "$label 完成，目前沒有可釋出的快取"
            }
            _state.update {
                it.copy(
                    shellBusy = false,
                    shellOutput = text,
                    lastFreed = if (gained > 0 && result.exitCode == 0) gained else it.lastFreed
                )
            }
            refresh()
        }
    }

    fun dismissNotice() {
        _state.update { it.copy(notice = null) }
    }
}
