package tw.vic.tidy.core

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import rikka.shizuku.Shizuku

/**
 * Expert mode. When Shizuku is running and has granted this app permission,
 * commands run with ADB-level rights — the only way, without root, to trim
 * other apps' caches.
 *
 * Everything here is wrapped: without Shizuku the class reports a status and
 * the rest of the app carries on.
 */
object ShizukuBridge {

    const val REQUEST_CODE = 4919
    private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    private const val SHIZUKU_HOME = "https://shizuku.rikka.app/"

    /**
     * Four distinct situations, each needing a different next step from the
     * user. pingBinder() alone only tells "running or not", so "not installed"
     * and "installed but stopped" (e.g. after a reboot) used to look the same.
     */
    enum class Status { NOT_INSTALLED, NOT_RUNNING, NOT_GRANTED, READY }

    fun status(context: Context): Status = when {
        !running() -> if (appInstalled(context)) Status.NOT_RUNNING else Status.NOT_INSTALLED
        !granted() -> Status.NOT_GRANTED
        else -> Status.READY
    }

    private fun appInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PKG, 0)
        true
    } catch (t: Throwable) {
        false
    }

    private fun running(): Boolean = try {
        Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }

    fun granted(): Boolean = try {
        running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (t: Throwable) {
            // Nothing to do — the panel only offers this when Shizuku is running.
        }
    }

    /** Opens the Shizuku app so the user can start it over wireless debugging. */
    fun openApp(context: Context): Boolean = try {
        val i = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)
        if (i == null) {
            false
        } else {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
            true
        }
    } catch (t: Throwable) {
        false
    }

    fun openDownloadPage(context: Context) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(SHIZUKU_HOME))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (t: Throwable) {
            // No browser; nothing sensible to fall back to.
        }
    }

    data class ShellResult(val exitCode: Int, val output: String)

    /**
     * Shizuku.newProcess is not part of the public surface, so it is reached
     * by reflection. Commands used here produce a few lines at most.
     */
    fun exec(command: String): ShellResult {
        if (!granted()) return ShellResult(-1, "尚未取得 Shizuku 授權")
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(
                null, arrayOf("sh", "-c", command), null, null
            ) as Process

            val out = process.inputStream.bufferedReader().use { it.readText() }
            val err = process.errorStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            ShellResult(code, (out + err).trim())
        } catch (t: Throwable) {
            ShellResult(-1, t.message ?: "指令執行失敗")
        }
    }

    /**
     * Asks the system to free cache space up to a target far larger than the
     * disk, which in practice clears every app's cache. Accounts, settings
     * and user data are untouched.
     *
     * "End background apps" (am kill-all) was removed on purpose: Android
     * restarts most of those processes within seconds, which costs battery,
     * and it contradicted the app's own "high RAM use is not slowness" note.
     */
    fun trimAllCaches(): ShellResult = exec("pm trim-caches 999999999999999")
}
